# Ayudantías

### :panda_face: Ayudantía 1: 10 de marzo
- [Pandas y Librerías](https://drive.google.com/file/d/16rRxuvwnkF6DaesNDBZrzisflrt-mzR8/view?usp=sharing)
- [Ejercicio práctico](https://colab.research.google.com/drive/1Ouiw_dviyVDu1vih48A9T6aLFVcTLD37?usp=sharing)